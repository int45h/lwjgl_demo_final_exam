package java.text;

import java.io.Serializable;

public class DecimalFormatSymbols implements Cloneable, Serializable {}
